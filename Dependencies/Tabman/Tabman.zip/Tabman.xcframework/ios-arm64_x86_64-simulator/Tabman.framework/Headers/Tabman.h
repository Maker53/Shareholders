//
//  Tabman.h
//  Tabman
//
//  Created by Merrick Sapsford on 17/02/2017.
//  Copyright © 2017 Merrick Sapsford. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Tabman.
FOUNDATION_EXPORT double TabmanVersionNumber;

//! Project version string for Tabman.
FOUNDATION_EXPORT const unsigned char TabmanVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Tabman/PublicHeader.h>


