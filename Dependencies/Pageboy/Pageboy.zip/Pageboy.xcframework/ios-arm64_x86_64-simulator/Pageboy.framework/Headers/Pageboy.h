//
//  Pageboy.h
//  Pageboy
//
//  Created by Merrick Sapsford on 04/01/2017.
//  Copyright © 2017 Merrick Sapsford. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Pageboy.
FOUNDATION_EXPORT double PageboyVersionNumber;

//! Project version string for Pageboy.
FOUNDATION_EXPORT const unsigned char PageboyVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Pageboy/PublicHeader.h>


