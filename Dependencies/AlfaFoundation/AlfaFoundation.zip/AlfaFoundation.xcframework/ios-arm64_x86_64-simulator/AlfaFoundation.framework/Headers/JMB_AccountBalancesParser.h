//
//  JMB_AccountBalancesParser.h
//  AlfaMobileConnection
//
//  Created by Slava Karpenko on 19/04/2010.
//  Reworked by Cyril Murzin 26/02/2013
//
//  Copyright 2010 Unreal Mojo (Mojo LLC). All rights reserved.
//

#import "JMB_Parser.h"

@interface JMB_AccountBalancesParser : JMB_Parser
{
}

@end
