//
//  JMB_TemplatePaymentParser.h
//  AlfaMobileConnection
//
//  Created by Cyril Murzin
//  Reworked by Cyril Murzin 26/02/2013
//
//  Copyright 2010 Unreal Mojo (Mojo LLC). All rights reserved.
//

#import "JMB_Parser.h"

@interface JMB_TemplatePaymentParser : JMB_Parser
{
@private
    int _phase;
}

- (BOOL)parseStep1;
- (BOOL)parseStep2;

@end
