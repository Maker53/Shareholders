//  Created by Viktor Bespalov on 14.04.2021.

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface NSBundle (AlfaFoundation_Extension)
+ (NSBundle *_Nullable)resourcesBundleForAlfaFoundation;
@end

NS_ASSUME_NONNULL_END
