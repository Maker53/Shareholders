//
//  MAB_SOAPParser.h
//
//  Created by Cyril Murzin
//  Copyright 2011 Unreal Mojo LLC. All rights reserved.
//

#import "BASE_Parser.h"

@interface MAB_SOAPParser : BASE_Parser
{
@protected
    BOOL                    _cdata;
}
@property (nonatomic, assign) BOOL allowCDATA;

- (BOOL)parseExact:(NSString*)irequest;
- (BOOL)parseResponse:(NSString*)irequest;
- (BOOL)parseFault;

@end

@interface CXMLNode (AMSOAPParserPrivate)
- (NSString*)exName;
@end
