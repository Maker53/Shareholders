//
//  JMB_ConversionPaymentParser.h
//  AlfaMobileConnection
//
//  Created by Cyril Murzin
//  Reworked by Cyril Murzin 27/02/2013
//
//  Copyright 2010 Unreal Mojo (Mojo LLC). All rights reserved.
//

#import "JMB_Parser.h"

@interface JMB_ConversionPaymentParser : JMB_Parser
{
@private
    NSString* __weak _prefix;
    int _phase;
}
@property (nonatomic, weak) NSString* prefix;

- (BOOL)parseStep1;
- (BOOL)parseStep2;

@end
