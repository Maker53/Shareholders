//
//  JMB_AccountMovementDetailsParser.h
//  AlfaMobileConnection
//
//  Created by Cyril Murzin
//  Reworked by Cyril Murzin 27/02/2013
//
//  Copyright 2010 Unreal Mojo (Mojo LLC). All rights reserved.
//

#import "JMB_Parser.h"

@interface JMB_AccountMovementDetailsParser : JMB_Parser
{
@private
    NSString* acctString;
    NSString* keyString;
}

- initWithString:(NSString*)istring forAccount:(NSString*)acct andKey:(NSString*)key;
@end
