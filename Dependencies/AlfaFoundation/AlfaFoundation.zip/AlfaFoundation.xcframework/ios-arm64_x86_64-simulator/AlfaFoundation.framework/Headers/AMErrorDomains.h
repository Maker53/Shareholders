/*!
    @header AMErrorDomains.h
    @project AlphaBank
    @author Andrey Toropchin
    @creation_date 30.08.11
    @copyright Copyright (c) 2011 Unreal Mojo LLC. All rights reserved.
*/

/*********        forward declarations, globals and typedefs        *********/

#import <UIKit/UIKit.h>

extern NSString* const ABGeoProviderErrorDomain;
extern NSString* const AMConnectionErrorDomain;
extern NSString* const AMP2PConnectionErrorDomain;
extern NSString* const ABFieldValidationErrorDomain;
