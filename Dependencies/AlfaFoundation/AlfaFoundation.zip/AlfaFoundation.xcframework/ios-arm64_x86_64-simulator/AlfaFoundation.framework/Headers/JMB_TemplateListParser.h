//
//  JMB_TemplateListParser.h
//  AlfaMobileConnection
//
//  Created by Cyril Murzin
//  Reworked by Cyril Murzin 27/02/2013
//
//  Copyright 2010 Unreal Mojo (Mojo LLC). All rights reserved.
//

#import "JMB_Parser.h"

@interface JMB_TemplateListParser : JMB_Parser
{
}

@end
