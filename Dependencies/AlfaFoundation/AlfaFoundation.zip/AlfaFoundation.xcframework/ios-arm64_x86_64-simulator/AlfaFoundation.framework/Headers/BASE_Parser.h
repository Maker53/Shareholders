//
//  BASE_Parser.h
//  AlphaBank
//
//  Created by Cyril Murzin on 2/25/13.
//  Copyright 2013 Unreal Mojo (Mojo LLC). All rights reserved.
//

#import <Foundation/Foundation.h>

#import "TouchXML.h"

@interface BASE_Parser : NSObject
{
@protected
    NSData*                 _data;

    NSError*                _error;
    id                      _result;
}
@property (nonatomic, readonly) id result;
@property (nonatomic, strong) NSError* error;

- (id)initWithData:(NSData*)idata;
- (id)initWithString:(NSString*)istring;

- (void)_spoolNode:(CXMLNode*)inode to:(NSMutableDictionary*)iodict parent:(NSMutableDictionary*)ioparentdict;
- (id)_spoolRoot:(CXMLNode*)inode;

- (BOOL)parse;

@end
