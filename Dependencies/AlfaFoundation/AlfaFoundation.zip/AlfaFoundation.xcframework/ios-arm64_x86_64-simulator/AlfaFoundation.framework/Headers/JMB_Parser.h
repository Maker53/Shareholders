//
//  JMB_Parser.h
//  AlphaBank
//
//  Created by Cyril Murzin on 2/25/13.
//  Copyright 2013 Unreal Mojo (Mojo LLC). All rights reserved.
//

#import "BASE_Parser.h"

@interface JMB_Parser : BASE_Parser
{
}

@end
