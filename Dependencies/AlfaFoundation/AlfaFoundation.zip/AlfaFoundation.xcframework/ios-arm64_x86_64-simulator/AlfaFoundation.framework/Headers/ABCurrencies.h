//
//  ABCurrencies.h
//  AlphaBank
//
//  Created by Cyri Murzin on 7/24/12.
//  Copyright (c) 2012 Unreal Mojo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ABCurrencies : NSObject
{
@private
    NSMutableArray*         _currenciesActual;
    NSMutableArray*         _currenciesHistoric;

    NSMutableDictionary*    _nameIndicies;
    NSMutableDictionary*    _codeIndicies;

    BOOL                    _historicFallback;
    BOOL                    _hackRUR;
}
@property (nonatomic, assign) BOOL historicFallback;
@property (nonatomic, assign) BOOL hackRUR;

+ (ABCurrencies*)shared;

// compatibility methods (will be obsoleted)
- (NSString*)currencyNameForID:(NSString*)iid;
- (NSString*)currencyIDForName:(NSString*)iname;
- (NSString*)currencySymbolForName:(NSString*)iname;
- (NSString*)stringWithCurrencySymbols:(NSString*)inputString;

@end
