//
//  JMB_OwnAccountsTransferParser.h
//  AlfaMobileConnection
//
//  Created by Cyril Murzin
//  Reworked by Cyril Murzin 27/02/2013
//
//  Copyright 2010 Unreal Mojo (Mojo LLC). All rights reserved.
//

#import "JMB_ConversionPaymentParser.h"

@interface JMB_OwnAccountsTransferParser : JMB_ConversionPaymentParser
{
}

@end
