//
//  UMJSONAdapter.h
//  AlphaBank
//
//  Created by Andrey Toropchin on 02.12.13.
//
//

#import <Foundation/Foundation.h>

// Note: This class is intended to be an adapter between built-in (iOS 5) NSJSONSerialization and JSONKit (for iOS 4 support),
//       when deployment target will be iOS 5 you can easily remove this.

@interface UMJSONAdapter : NSObject

+ (NSData*)dataWithJSONObject:(id)obj error:(NSError**)error;
+ (NSString*)stringWithJSONObject:(id)obj error:(NSError**)error;

+ (id)JSONObjectWithData:(NSData*)data error:(NSError**)error;
+ (id)JSONObjectWithString:(NSString*)string error:(NSError**)error;

+ (id)JSONMutableObjectWithData:(NSData*)data error:(NSError**)error;

@end
