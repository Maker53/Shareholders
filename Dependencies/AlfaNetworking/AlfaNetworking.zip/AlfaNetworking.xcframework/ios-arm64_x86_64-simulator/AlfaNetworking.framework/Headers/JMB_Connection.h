//
//  JMB_Connection.h
//  AlfaMobileConnection
//
//  Created by Slava Karpenko on 14/04/2010.
//  Copyright 2010 Unreal Mojo (Mojo LLC). All rights reserved.
//

#import <Foundation/Foundation.h>

#import "BASE_Connection.h"

@interface JMB_Connection : BASE_Connection
{
@protected
    BOOL _demo;
}

- (void)enterDemoMode;
- (BOOL)isDemoMode;
- (void)setDemoMode:(BOOL)demoMode;

- (void)doLogin;

- (void)doRequestTemplatePrepareID:(NSString*)templateID;
- (void)doRequestTemplateFill:(NSDictionary*)fields forID:(NSString*)uid;

- (void)doRequestInvoiceList;

- (void)doRequestPaymentConfirmID:(NSString*)uid withPassword:(NSString*)pass;

- (NSString*)_baseURL;
- (NSString*)_endpointJMBURL;
- (NSString*)_endpointJMBAURL;
- (NSString*)_appAPIVersion;

- (NSArray*)buildInputAccounts:(NSDictionary*)transferInputInfo;
- (NSArray*)buildOutputAccounts:(NSDictionary*)transferInputInfo forInput:(NSDictionary*)inputAccount;

@end
