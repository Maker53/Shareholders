//
//  JMBA_Connection.h
//  AlphaBank
//
//  Created by Cyril Murzin on 6/15/12.
//  Copyright 2012 Unreal Mojo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JMB_Connection.h"

extern NSString* const kJMBATransferTypeEMoney;
extern NSString* const kJMBATransferTypeECatalog;
extern NSString* const kJMBATransferTypeExternal;
extern NSString* const kJMBATransferTypeInternal;
extern NSString* const kJMBATransferTypeByEMail;
extern NSString* const kJMBATransferTypeByAccount;
extern NSString* const kJMBATransferTypeByPhoneNumber;
extern NSString* const kJMBATransferTypeByPhoneNumberPopularClientTransfer;
extern NSString* const kJMBATransferTypeByName;
extern NSString* const kJMBATransferTypeAlfaCheck;
extern NSString* const kJMBATransferTypeAlfaCheckUpdate;
extern NSString* const kJMBATransferTypeTemplate;
extern NSString* const kJMBATransferTypeFines;
extern NSString* const kJMBATransferTypeFinesKZ;
extern NSString* const kJMBATransferTypeDepositBY;
extern NSString* const kJMBATransferTypeDepositKZ;
extern NSString* const kJMBATransferTypeOneButtonPaymentBY;
extern NSString* const kJMBATransferTypeRepeat;

extern NSString* const kJMBACatalogTypeEMoney;
extern NSString* const kJMBACatalogTypeECatalog;
extern NSString* const kJMBACatalogTypeBank;
extern NSString* const kJMBACatalogTypeCountries;
extern NSString* const kJMBACatalogTypeCurrencies;
extern NSString* const kJMBACatalogTypeMobile;
extern NSString* const kJMBACatalogTypeTransport;

@protocol JMBAStubsConfigurer;

@interface JMBA_Connection : JMB_Connection
{
}

- (instancetype)initWithJmbaStubsConfigurer:(id<JMBAStubsConfigurer>)jmbaStubsConfigurer;

// LOGIN
- (void)doLoginWithAccessToken;
- (void)doGetSessionForWatchWithAccessToken;
- (void)doLoginEx:(NSString*)token;

// GOALS
- (void)doGetGoalsList;

- (void)doCreateGoalInit;
- (void)doCreateGoal:(NSString*)iname amount:(NSString*)iamount currency:(NSString*)icur expiring:(NSDate*)iexp;
- (void)doCreateGoalConfirm:(NSString*)iuid;

- (void)doViewGoal:(NSString*)igoal;
- (void)doEditGoal:(NSString*)igoal;
- (void)doSaveGoal:(NSString*)iuid name:(NSString*)iname amount:(NSString*)iamount expiring:(NSDate*)iexp;

- (void)doReplenishGoal:(NSString*)igoal;
- (void)doReplenishGoal:(NSString*)igoal from:(NSString*)ifrom amount:(NSString*)iamount currency:(NSString*)icur;
- (void)doReplenishGoal:(NSString*)igoal confirm:(NSString*)iuid;

- (void)doWithdrawGoal:(NSString*)igoal;
- (void)doWithdrawGoal:(NSString*)igoal to:(NSString*)ito amount:(NSString*)iamount currency:(NSString*)icur;
- (void)doWithdrawGoal:(NSString*)igoal confirm:(NSString*)iuid;

- (void)doDeleteGoal:(NSString*)igoal withdrawTo:(NSString*)iaccountOrNil; /* use nil to obtain accounts list */
- (void)doDeleteGoalConfirm:(NSString*)iuid;

// PFM
- (void)doRequestPFMGetCategories;
- (void)doRequestPFMSetForOperationID:(NSString*)operationID categoryID:(NSString*)categoryOrNil userComment:(NSString*)commentOrNil;

// TRANSFERS
- (void)doTransferGetFields:(NSString*)itype parameters:(NSDictionary*)parameters;
- (void)doTransferRegister:(NSString*)itype parameters:(NSDictionary*)parameters;
- (void)doTransferRegister:(NSString*)itype forCardID:(NSString*)cardID parameters:(NSDictionary*)parameters;
- (void)doTransferConfirm:(NSString*)iuid type:(NSString*)itype password:(NSString*)ipassword;
- (void)doTransferConfirmWithType:(NSString*)type md:(NSString*)md paRes:(NSString*)paRes;
- (void)doGetCatalog:(NSString*)itype parameters:(NSDictionary*)parameters;
- (void)doGetBank:(NSString*)ibic;
- (void)doGenerateOTP:(NSString*)iuid;
- (void)doGenerateOTP:(NSString*)iuid type:(NSString*)type;

// CARDS
- (void)doRequestPlasticCardsList:(BOOL)withTokens;
- (void)doSetStatus:(AMCardBlockStatus)st ofCard:(NSString*)iid virtual:(BOOL)vCard;
- (void)doSetStatus:(AMCardBlockStatus)st virtual:(BOOL)vCard confirm:(NSString*)iuid password:(NSString*)ipassword;
- (void)doCardRemapInit;
- (void)doCardRemap:(NSString*)iid to:(NSString*)to;
- (void)doCardRemapConfirm:(NSString*)iuid password:(NSString*)ipassword;
- (void)doRequestCardLimits:(NSString*)iid;
- (void)doRequestCard:(NSString*)icard editLimitFields:(int)iid;
- (void)doRequestCard:(NSString*)icard editLimitConfirm:(int)iid parameters:(NSDictionary*)parameters;
- (void)doRequestCardAddLimitFields:(NSString*)icard;
- (void)doRequestCard:(NSString*)icard addLimitConfirm:(NSDictionary*)parameters;
- (void)doRequestCard:(NSString*)icard deleteLimit:(int)iid;
- (void)doRequestVCardCVC2Info:(NSString*)icard;
- (void)doRequestVCardDelete:(NSString*)icard;
- (void)doRequestVCardDeleteConfirm:(NSString*)iuid password:(NSString*)ipassword;

// NEW TEMPLATES
- (void)doRequestNewTemplatePrepareID:(NSString*)templateID isPayment:(BOOL)pay isP2PTemplate:(BOOL)isP2PTemplate;

- (void)doRequestAgreeWithPassportNotification:(NSString *)notificationID parameters:(NSDictionary *)parameters;

// P2P
- (void)doRequestCustomerCardsList;
- (void)doRequestDeleteCardWithIdentifier:(NSString*)cardIdentifier debit:(BOOL)debit;
- (void)doRequestCalculateFeeTemplateTransferWithIdentifier:(NSString*)templateID amount:(NSNumber*)amount;
- (void)doRequestCalculateFeeWithParameters:(NSDictionary *)parameters;
- (void)doRequestSaveTransferTemplateWithIdentifier:(NSString*)templateID fields:(NSDictionary*)fields;
- (void)doRequestEditTransferTemplateWithIdentifier:(NSString*)templateID name:(NSString*)name amount:(NSNumber*)amount;
- (void)doRequestDeleteTransferTemplateWithIdentifier:(NSString*)templateID;
- (void)doRequestTransferTemplateFieldsWithReference:(NSString*)reference;
- (void)doRequestTransferTemplateDetailsWithIdentifier:(NSString*)templateID forPayment:(BOOL)isPayment isP2PTemplate:(BOOL)isP2PTemplate;

- (void)doRequestOperatorByPhoneNumber:(NSString*)phoneNumber;
- (void)doRequestAccountChangeName:(NSString*)accountNumber accountName:(NSString*)accountName;

- (void)doRequestMobileRechargeFillAccount:(NSString*)accountNumber amount:(NSString*)amount operatorID:(NSString*)operatorID domesticPhoneNumber:(NSString*)domesticPhoneNumber curency:(NSString *)curency;

// EIO
- (RequestOperation*)doRequestCommonMovementsWithBody:(NSDictionary *)body;
- (RequestOperation*)doRequestCommonAccountMovementFilters;
- (RequestOperation*)doRequestCommonAccountDetails:(NSString*)account;
- (RequestOperation*)doRequestCommonAccounts;

- (NSArray*)buildInputAccountsFromJSON:(NSDictionary*)json;
- (NSArray*)buildOutputAccountsFromJSON:(NSDictionary*)json;

// "virtual" methods
- (NSString*)_baseURL;
- (NSString*)_endpointJMBURL;
- (NSString*)_endpointJMBAURL;
- (NSString*)_appAPIVersion;

// for JMBA
- (void)doRequestPaymentConfirmIDNewProtocol:(NSString*)uid withPassword:(NSString*)pass;

// currency exchange rates
- (void)doGetExchangeRateWithDebitCurr:(NSString *)debitCurrency creditCurrency:(NSString *)creditCurrency parameters:(NSDictionary *)parameters;

// suggestions
- (void)doGetSuggestionsForTransferType:(NSString *)itype parameters:(NSDictionary *)parameters;

- (void)doRequestGetVIPManagerInfo;

- (void)doRequestAccountsForMobilePayment;

// Geoserver
- (void)doRequestGetCurrencyRates;
- (void)doRequestGetCurrencyRatesWithParameters:(NSDictionary *)parameters;

// PDF receipt
- (void)doRequestGetOperationReceiptInPdf:(NSString *)reference;

// Apple Pay
- (void)doRequestCryptoData:(NSDictionary *)parameters;
- (void)doRequestVirtualCryptoData:(NSDictionary *)parameters;

// Token Management
- (void)doRequestDeleteTokens:(NSDictionary *)parameters;
- (void)doRequestUnsuspendTokens:(NSDictionary *)parameters;
- (void)doRequestSuspendTokens:(NSDictionary *)parameters;

// Fast fee calculation
- (void)doRequestFastCalculateFee:(NSString *)fromCardNumber fromCardID:(NSString *)fromCardID cardID:(NSString *)cardID recipientType:(NSString* )recipientType;

// Get card color
- (void)doRequestGetCardColor:(NSString *)cardBin;

- (NSMutableDictionary*)_convertFields:(NSDictionary*)jsonresult;
- (NSError*)_jmbaErrorFor:(NSDictionary*)idict;
- (BASE_Request*)_prepareRequest:(NSDictionary*)options parametersToSend:(id)parameters mainType:(NSString*)mainType;

@end
