//
//  JMBA_CardLimit.h
//  AlphaBank
//
//  Created by Cyril Murzin on 4/11/13.
//  Copyright 2013 Unreal Mojo (Mojo LLC). All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JMBA_CardLimit : NSObject
{
@private
    int             _id;

    NSDate*         _startDate;
    NSDate*         _endDate;

    NSDictionary*   _type;

    NSNumber*       _singleAmount;
    NSString*       _singleAmountCurrency;

    NSString*       _periodDescription;
    NSNumber*       _periodAmount;
    NSString*       _periodAmountCurrency;

    NSString*       _inclusiveCountryDescription;
    NSString*       _countryGroup;
    NSDictionary*   _countries;
}
@property (nonatomic, readonly) int identifier;
@property (nonatomic, strong, readonly) NSDate* startDate;
@property (nonatomic, strong, readonly) NSDate* endDate;
@property (nonatomic, strong, readonly) NSDictionary* type;
@property (nonatomic, strong, readonly) NSNumber* singleAmount;
@property (nonatomic, strong, readonly) NSString* singleAmountCurrency;
@property (nonatomic, strong, readonly) NSString* periodDescription;
@property (nonatomic, strong, readonly) NSNumber* periodAmount;
@property (nonatomic, strong, readonly) NSString* periodAmountCurrency;
@property (nonatomic, strong, readonly) NSString* inclusiveCountryDescription;
@property (nonatomic, strong, readonly) NSString* countryGroup;
@property (nonatomic, strong, readonly) NSDictionary* countries;

+ (JMBA_CardLimit*)limitWithDictionary:(NSDictionary*)idict;

- (NSString*)typeDescription;
- (NSString*)countriesDescription;

@end
