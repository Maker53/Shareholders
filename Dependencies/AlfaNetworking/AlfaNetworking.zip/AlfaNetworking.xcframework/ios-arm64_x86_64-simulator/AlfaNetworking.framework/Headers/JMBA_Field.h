//
//  JMBA_Field.h
//  AlphaBank
//
//  Created by Cyril Murzin on 6/26/12.
//  Copyright 2012 Unreal Mojo. All rights reserved.
//

#import <Foundation/Foundation.h>

enum _JMBA_InpField
{
    JMBAIF_Undefined = 0,
    JMBAIF_List,
    JMBAIF_Zoned,
    JMBAIF_Char,
    JMBAIF_Date
};
typedef enum _JMBA_InpField JMBA_InpField_t;

enum _JMBA_Field
{
    JMBAF_Undefined = 0,
    JMBAF_String,
    JMBAF_Boolean,
    JMBAF_Integer,
    JMBAF_Decimal,
    JMBAF_Date,
    JMBAF_Composite,
    JMBAF_Map,
    JMBAF_ListMask = 512
};
typedef enum _JMBA_Field JMBA_Field_t;

enum _JMBA_RenderingType
{
    JMBART_Unknown = 0,
    JMBART_Attention,
    JMBART_Amount,
    JMBART_Label,
    JMBART_Date,
    JMBART_Phone1,
    JMBART_InsAmount,
    JMBART_Month1,
    JMBART_Phone2,
    JMBART_Combobox,
    JMBART_Field,
    JMBART_Account,
    JMBART_ClName,
    JMBART_Checkbox,
    JMBART_Diapason,
    JMBART_FillBySymb,
    JMBART_Select,
    JMBART_Custom,
    JMBART_GroupSection
};
typedef enum _JMBA_RenderingType JMBA_RenderingType_t;

@interface JMBA_Field : NSObject
{
@private

    NSString*       _id;            /* field identifier, "name" */
    NSString*       _title;         /* title of field, "description" */
    NSString*       _hint;          /* hint text for field, "hint" */

    BOOL            _required;      /* field is required, "required" */
    BOOL            _visible;       /* field is visible, "visible" */
    BOOL            _protected;     /* "isProtected" */

    JMBA_Field_t    _contentType;   /* "contentType", decoded type of data */
    NSString*       _contentType_composed; /* "contentType" extras, name for composite types */

    JMBA_InpField_t _inputType;     /* "type", decoded type of input field */

    id              _value;         /* field isomorphic value, "value", type depends on _type member */
    NSString*       _defaultValue;  /* default value of string value, "defaultValue" */

    NSDictionary*   _rendering;     /* rendering behaviour, "rendering" */
    JMBA_RenderingType_t _renderingType; /* decoded "renderingType" */
    NSRegularExpression* _regex; /* compiled verification regexp */

    NSString*       _errorMessage;  /* "validationErrorMessage" */
}
@property (nonatomic, strong) NSString* identifier; /* identifier is not readonly anymore */
@property (nonatomic, strong) NSString* title; /* title is not readonly anymore */
@property (nonatomic, strong) NSString* hint; /* hint is not readonly anymore */
@property (nonatomic, readonly) BOOL required;
@property (nonatomic, readonly) BOOL visible;
@property (nonatomic, readonly) BOOL protected;
@property (nonatomic, readonly) JMBA_Field_t type;
@property (nonatomic, strong, readonly) NSString* typeComposed;
@property (nonatomic, readonly) JMBA_InpField_t inputType;
@property (nonatomic, strong) id value; /* value is not readonly anymore */
@property (nonatomic, strong, readonly) NSString* defaultValue;
@property (nonatomic, strong, readonly) NSDictionary* rendering;
@property (nonatomic, readonly) JMBA_RenderingType_t renderingType;
@property (nonatomic, readonly) NSInteger renderingMaxFieldLength;
@property (nonatomic, strong, readonly) NSString* errorMessage;

+ (JMBA_Field*)fieldWithDictionary:(NSDictionary*)idict;

- (BOOL)verifyValue:(id)value;

@end
