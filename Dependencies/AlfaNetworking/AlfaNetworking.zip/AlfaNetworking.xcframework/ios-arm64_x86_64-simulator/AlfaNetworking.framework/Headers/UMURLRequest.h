/*!
    @header UMURLRequest.h
    @author Sergey Alexeev
    @creation_date 26.11.11
    @copyright Copyright (C) 2011 Unreal Mojo LLC. All rights reserved.
*/

#import <Foundation/Foundation.h>

@class UMURLRequest;

@protocol UMURLRequestDelegate <NSObject>
@required
- (void)requestDidFinish:(UMURLRequest*)request;
- (void)requestDidFail:(UMURLRequest*)request;
@optional
- (void)requestDidStart:(UMURLRequest*)request;
- (NSURLRequest*)request:(UMURLRequest*)request willSendRedirectRequest:(NSURLRequest*)URLRequest;
@end


@interface UMURLRequest : NSOperation <NSCopying>
{
    id<UMURLRequestDelegate> _delegate;
    SEL _requestDidFinish;
    SEL _requestDidFail;
    SEL _requestDidStart;
    SEL _willSendRedirectRequest;

    NSTimeInterval _timeoutInterval;
    NSString* _requestMethod;
    NSMutableDictionary* _requestHeaders;
    NSString* _destinationFilePath;
    NSData* _postBody;
    BOOL _usesVoIPNetworkService;
    BOOL _shouldHandleCookies;

    NSData* _responseData;
    id _userInfo;

    NSError* _error;

    NSURL* _url;
    NSMutableURLRequest* _urlRequest;
    NSURLResponse* _urlResponse;
    NSURLResponse* _urlRedirectResponse;
    NSURLConnection* _urlConnection;
    NSInteger _dataReceivedCounter;
    NSStringEncoding _responseDefaultContentEncoding;

    BOOL _isExecutingInternal;
    BOOL _isFinishedInternal;
}
@property (nonatomic, weak) id delegate;
@property (nonatomic, assign) SEL requestDidFinish;
@property (nonatomic, assign) SEL requestDidFail;
@property (nonatomic, assign) SEL requestDidStart;
@property (nonatomic, assign) SEL willSendRedirectRequest;

@property (retain) NSURL* url;
@property (assign) NSTimeInterval timeoutInterval;
@property (retain) NSString* requestMethod;
@property (retain) NSURLResponse* urlResponse;
@property (retain) NSURLResponse* urlRedirectResponse;
@property (retain) NSURLConnection* urlConnection;
@property (retain) NSMutableDictionary* requestHeaders;
@property (retain) NSData* postBody;
@property (retain) NSString* destinationFilePath;
@property (nonatomic) BOOL usesVoIPNetworkService;
@property (nonatomic) BOOL shouldHandleCookies;
@property (retain, readonly) NSData* responseData;
@property (readonly) NSString* responseMIMEType;
@property (readonly) long long responseContentLength;
@property (readonly) NSStringEncoding responseContentEncoding;
@property (assign) NSStringEncoding responseDefaultContentEncoding;
@property (retain, readonly) NSDictionary* responseHeaders;
@property (readonly) NSInteger responseStatusCode;
@property (retain, readonly) NSString* responseStatusString;
@property (retain, readonly) NSError* error;

@property (retain) id userInfo;

- (void)silentCancel;

- (id)initWithURL:(NSURL*)url;
- (NSString*)responseString;

- (void)addRequestHeader:(NSString*)header value:(NSString*)value;

- (void)startSync;

@end
