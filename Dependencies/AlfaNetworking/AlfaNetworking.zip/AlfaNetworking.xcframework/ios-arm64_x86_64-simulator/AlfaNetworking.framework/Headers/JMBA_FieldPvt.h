//
//  JMBA_FieldPvt.h
//  AlphaBank
//
//  Created by Cyril Murzin on 6/30/12.
//  Copyright 2012 Unreal Mojo. All rights reserved.
//

#import "JMBA_Field.h"

#import <Foundation/Foundation.h>

@interface JMBA_Field ()
@property (nonatomic, readwrite) BOOL required;
@property (nonatomic, readwrite) BOOL visible;
@property (nonatomic, readwrite) BOOL protected;
@property (nonatomic, readwrite) JMBA_Field_t type;
@property (nonatomic, strong, readwrite) NSString* typeComposed;
@property (nonatomic, readwrite) JMBA_InpField_t inputType;
@property (nonatomic, strong, readwrite) NSString* defaultValue;
@property (nonatomic, strong, readwrite) NSDictionary* rendering;
@property (nonatomic, readwrite) JMBA_RenderingType_t renderingType;
@property (nonatomic, strong) NSRegularExpression* regex;
@property (nonatomic, strong, readwrite) NSString* errorMessage;

+ (JMBA_Field_t)_contentTypeOfString:(NSString*)str withComposite:(NSString**)composite;
+ (JMBA_InpField_t)_inputTypeOfString:(NSString*)str;
@end

