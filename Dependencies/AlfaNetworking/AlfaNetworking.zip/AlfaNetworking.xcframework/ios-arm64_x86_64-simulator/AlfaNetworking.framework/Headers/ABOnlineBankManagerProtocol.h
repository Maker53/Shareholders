//  Created by Viktor Bespalov on 28.08.2020.

#ifndef ABOnlineBankManagerProtocol_h
#define ABOnlineBankManagerProtocol_h

@protocol ABOnlineBankManagerProtocol
- (BOOL)isDemoMode;
- (NSInteger)numberOfDetailsViewingForAccount:(NSDictionary*)account;
- (id)doRequestCommonAccountMovementFilters;
- (id)doRequestCommonMovementsWithBody:(NSDictionary *)body;
- (void)doGetExchangeRateWithDebitCurr:(NSString *)debitCurrency creditCurrency:(NSString *)creditCurrency parameters:(NSDictionary *)parameters;
- (void)doGetSuggestionsForTransferType:(NSString *)itype parameters:(NSDictionary *)parameters;
- (void)doRequestAccountsForMobilePayment;
- (void)doRequestCustomerCardsList;
- (void)doRequestGetCardColor:(NSString *)cardBin;
- (void)doRequestGetCatalog:(NSString*)itype parameters:(NSDictionary*)parameters;
- (void)doRequestInvoiceList;
- (void)doRequestMobileRechargeFillAccount:(NSString*)accountNumber amount:(NSString*)amount operatorID:(NSString*)operatorID domesticPhoneNumber:(NSString*)domesticPhoneNumber curency:(NSString *)curency;
- (void)doRequestOperatorByPhoneNumber:(NSString *)phoneNumber;
- (void)doRequestPaymentConfirmIDNewProtocol:(NSString*)uid withPassword:(NSString*)pass;
- (void)doRequestPlasticCardsList:(BOOL)withTokens;
- (void)doRequestTransferConfirm:(NSString*)iuid type:(NSString*)itype password:(NSString*)ipassword;
- (void)doRequestTransferRegister:(NSString*)itype parameters:(NSDictionary*)parameters;
- (void)enterDemoMode;
- (void)getSessionForWatchWithAccessToken;
- (void)loginToServerWithAccessToken;
- (void)resetStubConfigurerUsername;
- (void)setBaseURL:(NSString*)url;
@end

#endif /* ABOnlineBankManagerProtocol_h */
