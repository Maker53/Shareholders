/*!
 @header ABOnlineBankManager.h
 @project AlphaBank
 @author Anton Turov
 @creation_date 19.04.2010
 @copyright Copyright (c) 2010 Unreal Mojo (Mojo LLC). All rights reserved.
 @abstract Interface for ABOnlineBankManager.
 */

/*********        includes        *********/

#import "ABOnlineBankManagerProtocol.h"
#import "JMBA_Connection.h"
#import "BASE_Connection.h"

@protocol JMBAStubsConfigurer;

typedef NS_CLOSED_ENUM(NSInteger, ABErrorCode);

/*********        interface for ABOnlineBankManager        *********/

@interface ABOnlineBankManager : NSObject <ABOnlineBankManagerProtocol, BASE_ConnectionDelegate>
{
@private
    JMBA_Connection* _connection;
    BOOL _baseURLChanged;
}

+ (ABOnlineBankManager*)sharedOnlineBankManager;

@property (nonatomic, strong, readonly) NSArray* notificationsList;

- (void)setupJmbaStubsConfigurer:(id<JMBAStubsConfigurer>)jmbaStubsConfigurer;
- (void)resetStubConfigurerUsername;

- (void)setBaseURL:(NSString*)url;

- (BOOL)isValidAccount;
- (BOOL)isLoggedIn;
- (NSString*)login;
- (NSString*)password;
- (void)logout;

- (void)enterDemoMode;
- (BOOL)isDemoMode;
- (void)setDemoMode:(BOOL)demoMode;
- (NSArray*)accounts;

// API requests forwarders

- (BOOL)loginExToServerWithPassword:(NSString*)password;
- (BOOL)loginExToServerWithToken:(NSString*)token;
- (void)loginToServerWithAccessToken;
- (void)getSessionForWatchWithAccessToken;

- (void)doRequestAccountChangeName:(NSString*)accountNumber accountName:(NSString*)accountName;

- (void)doRequestPaymentConfirmID:(NSString*)uid withPassword:(NSString*)pass;
- (void)doRequestPaymentConfirmIDNewProtocol:(NSString*)uid withPassword:(NSString*)pass;

- (void)doRequestMobileRechargeFillAccount:(NSString*)accountNumber amount:(NSString*)amount operatorID:(NSString*)operatorID domesticPhoneNumber:(NSString*)domesticPhoneNumber curency:(NSString *)curency;

- (void)doRequestTemplatePrepareID:(NSString*)templateID;
- (void)doRequestTemplateFill:(NSDictionary*)fields forID:(NSString*)uid;

- (void)doRequestNewTemplatePrepareID:(NSString*)templateID isPayment:(BOOL)pay isP2PTemplate:(BOOL)isP2PTemplate;

- (void)doRequestInvoiceList;

- (void)doRequestGoalsList;
- (void)doRequestCreateGoal;
- (void)doRequestCreateGoal:(NSString*)iname amount:(NSString*)iamount currency:(NSString*)icur expiring:(NSDate*)iexp;
- (void)doRequestCreateGoalConfirm:(NSString*)iuid;
- (void)doRequestViewGoal:(NSString*)igoal;
- (void)doRequestEditGoal:(NSString*)igoal;
- (void)doRequestSaveGoal:(NSString*)iuid name:(NSString*)iname amount:(NSString*)iamount expiring:(NSDate*)iexp;
- (void)doRequestDeleteGoal:(NSString*)igoal withdrawTo:(NSString*)iaccountOrNil;
- (void)doRequestDeleteGoalConfirm:(NSString*)iuid;
- (void)doRequestReplenishGoal:(NSString*)igoal;
- (void)doRequestReplenishGoal:(NSString*)igoal from:(NSString*)ifrom amount:(NSString*)iamount currency:(NSString*)icur;
- (void)doRequestReplenishGoal:(NSString*)igoal confirm:(NSString*)iuid;
- (void)doRequestWithdrawGoal:(NSString*)igoal;
- (void)doRequestWithdrawGoal:(NSString*)igoal to:(NSString*)ito amount:(NSString*)iamount currency:(NSString*)icur;
- (void)doRequestWithdrawGoal:(NSString*)igoal confirm:(NSString*)iuid;

- (void)doRequestPFMGetCategories;
- (void)doRequestPFMSetForOperationID:(NSString*)operationID categoryID:(NSString*)categoryOrNil userComment:(NSString*)commentOrNil;

- (void)doRequestTransferGetFields:(NSString*)itype parameters:(NSDictionary*)parameters;
- (void)doRequestTransferRegister:(NSString*)itype parameters:(NSDictionary*)parameters;
- (void)doRequestTransferRegister:(NSString*)itype forCardID:(NSString*)cardID parameters:(NSDictionary*)parameters;
- (void)doRequestTransferConfirm:(NSString*)iuid type:(NSString*)itype password:(NSString*)ipassword;
- (void)doRequestTransferConfirmWithType:(NSString*)type md:(NSString*)md paRes:(NSString*)paRes;
- (void)doGetExchangeRateWithDebitCurr:(NSString *)debitCurrency creditCurrency:(NSString *)creditCurrency parameters:(NSDictionary *)parameters;
- (void)doGetSuggestionsForTransferType:(NSString *)itype parameters:(NSDictionary *)parameters;
- (void)doRequestGetCatalog:(NSString*)itype parameters:(NSDictionary*)parameters;
- (void)doRequestGetBank:(NSString*)ibic;
- (void)doRequestGenerateOTP:(NSString*)iuid;
- (void)doRequestGenerateOTP:(NSString*)iuid type:(NSString*)type;

- (void)doRequestPlasticCardsList:(BOOL)withTokens;
- (void)doRequestCardSetStatus:(AMCardBlockStatus)st of:(NSString*)iid virtual:(BOOL)vCard;
- (void)doRequestCardSetStatus:(AMCardBlockStatus)st virtual:(BOOL)vCard confirm:(NSString*)iuid password:(NSString*)ipassword;
- (void)doRequestCardRemapInit;
- (void)doRequestCardRemap:(NSString*)iid to:(NSString*)to;
- (void)doRequestCardRemapConfirm:(NSString*)iuid password:(NSString*)ipassword;
- (void)doRequestCardLimits:(NSString*)iid;
- (void)doRequestCard:(NSString*)icard editLimitFields:(int)iid;
- (void)doRequestCard:(NSString*)icard editLimitConfirm:(int)iid parameters:(NSDictionary*)parameters;
- (void)doRequestCardAddLimitFields:(NSString*)icard;
- (void)doRequestCard:(NSString*)icard addLimitConfirm:(NSDictionary*)parameters;
- (void)doRequestCard:(NSString*)icard deleteLimit:(int)iid;
 /* AM.UA specific */
- (void)doRequestVCardCVC2Info:(NSString*)icard;
- (void)doRequestVCardDelete:(NSString*)icard;
- (void)doRequestVCardDeleteConfirm:(NSString*)iuid password:(NSString*)ipassword;

- (void)doRequestAgreeWithPassportNotification:(NSString *)notificationID parameters:(NSDictionary *)parameters;

// P2P
- (void)doRequestCustomerCardsList;
- (void)doRequestDeleteCardWithIdentifier:(NSString*)cardIdentifier debit:(BOOL)debit;
- (void)doRequestCalculateFeeTemplateTransferWithIdentifier:(NSString*)templateID amount:(NSNumber*)amount;
- (void)doRequestSaveTransferTemplateWithIdentifier:(NSString*)templateID fields:(NSDictionary*)fields;
- (void)doRequestEditTransferTemplateWithIdentifier:(NSString*)templateID name:(NSString*)name amount:(NSNumber*)amount;
- (void)doRequestDeleteTransferTemplateWithIdentifier:(NSString*)templateID;
- (void)doRequestTransferTemplateFieldsWithReference: (NSString*) reference;
- (void)doRequestTransferTemplateDetailsWithIdentifier:(NSString*)templateID forPayment:(BOOL)isPayment isP2PTemplate:(BOOL) isP2PTemplate;

- (void)doRequestOperatorByPhoneNumber:(NSString *)phoneNumber;

// VIP manager
- (void)doRequestGetVIPManagerInfo;

// MobileAccount mobile info
- (void)doRequestAccountsForMobilePayment;

// EIO
- (RequestOperation*)doRequestCommonMovementsWithBody:(NSDictionary *)body;
- (RequestOperation*)doRequestCommonAccountMovementFilters;
- (RequestOperation*)doRequestCommonAccountDetails:(NSString*)account;
- (RequestOperation*)doRequestCommonAccounts;

// Geoserver
- (void)doRequestGetCurrencyRates;
- (void)doRequestGetCurrencyRatesWithParameters:(NSDictionary *)parameters;

// PDF receipt
- (void)doRequestGetOperationReceiptInPDF:(NSString *)reference;

// Apple Pay
- (void)doRequestCryptoData:(NSDictionary *)parameters;
- (void)doRequestVirtualCryptoData:(NSDictionary *)parameters;

// Token Management
- (void)doRequestDeleteTokens:(NSDictionary *)parameters;
- (void)doRequestSuspendTokens:(NSDictionary *)parameters;
- (void)doRequestUnsuspendTokens:(NSDictionary *)parameters;

// Fast fee calculation
- (void)doRequestFastCalculateFee:(NSString *)fromCardNumber fromCardID:(NSString *)fromCardID cardID:(NSString *)cardID recipientType:(NSString* )recipientType;
- (void)doRequestCalculateFeeWithParameters:(NSDictionary *)parameters;

// Get card color and image URL
- (void)doRequestGetCardColor:(NSString *)cardBin;

// utility

- (NSInteger)numberOfDetailsViewingForAccount:(NSDictionary*)account;

- (NSArray*)buildInputAccounts:(NSDictionary*)transferInputInfo;
- (NSArray*)buildInputAccountsFromJSON:(NSDictionary*)json;
- (NSArray*)buildOutputAccounts:(NSDictionary*)transferInputInfo forInput:(NSDictionary*)inputAccount;
- (NSArray*)buildOutputAccountsFromJSON:(NSDictionary*)json;

- (NSString*)amountCorrectString:(NSString*)inputString error:(ABErrorCode*)error;

@end
