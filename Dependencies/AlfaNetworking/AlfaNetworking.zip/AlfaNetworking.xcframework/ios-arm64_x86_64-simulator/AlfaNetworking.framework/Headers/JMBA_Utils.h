//
//  JMBA_Utils.h
//  AlphaBank
//
//  Created by Cyril Murzin on 6/27/12.
//  Copyright 2012 Unreal Mojo. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "JMBA_Field.h"

@interface JMBA_Utils : NSObject
{
}

+ (NSString*)stringByDayDate:(NSDate*)date;
+ (NSString*)stringByDayDate:(NSDate*)date separator:(NSString*)separatorOrNil;
+ (NSString*)stringByMonthDate:(NSDate*)date separator:(NSString*)sepOrNil;
+ (NSDate*)dateByDayString:(NSString*)str;
+ (NSDate*)dateByMonthString:(NSString*)str;
+ (NSDate*)dateAndTimeByDayString:(NSString*)str;

+ (NSNumber*)numberWithValue:(id)value dbl:(BOOL)dbl;

+ (JMBA_Field*)fieldForID:(NSString*)iid fromArray:(NSArray*)iarray;
@end
