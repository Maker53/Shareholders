//
//  BASE_Connection.h
//  AlfaMobileConnection
//
//  Created by Slava Karpenko on 14/04/2010.
//  Copyright 2010 Unreal Mojo (Mojo LLC). All rights reserved.
//  Purged by Cyril Murzin
//  Copyright 2011 Unreal Mojo (Mojo LLC). All rights reserved.
//  ------------------------------------------------------------------------------------------------------------------------------------------------
//  ------------------------------------------------------------------------------------------------------------------------------------------------
//                                         #@@@@@@@@@@@@&*
//                                      &@@%%%%%%%%%%%%%%&@@@*
//                                   ,@@&%%%%%%%%%%%%%%%%%%%%@@(
//                                  @@%%%%%%%%%%&@@@&%%%%%%%%%%@@                                            ,///*
//                                 @@%%%%%%%@@@%(///(&@@@%%%%%%%@&                                     *&@@@@&%%%&&@@@&,
//                                &@%%%%%%&@%*//*****/**(@@%%%%%%@@%@@@@@@@@@@@@@@@@@@@@@@&(,       %@@&%%%%%%%%%%%%%%%@@*
//                                @&%%%%%%@#////****///*//&@&%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%&@@@@#@@&%%%%%%%%%%@@@@&%%%%%@&
//                               *@&%%%%%&@//***/*///#@@@&%%%%%%%%%%%%%%%%%%%%%%%%%%%%########%%%%&@@@%%%%@@@%*,,,,,#@@%%%@@
//                                @&%%%%%%@(**/*/(@@@&%%%%%&@@@@@@@@&%%%%%%%%%%######################%@@@@(,,,,,,,,,,,@@%%&@*
//                                &@%%%%%%@@//*%@@%%%%%@@@%*         (@@@&%#############################%@@@*,,,,,,,,,#@%%%@/
//                                ,@&%%%%%%@@@@&%%%%@@@,                 #@@%##############################&@@/,,,,,,,@@%%&@,
//                                 /@&%%%%%%&%%%%%@@,                       %@################%@@@@@@@@&%##%@@/*,,,,,&@%%%@%
//                                  (@&%&@%%%%%%%@/                           @@############&@@&/         (@@@%%@%,,@@%%%@@
//                                   /@@@%%%%%%&@                              &@#########@@#                 &@&@@@@%%%@@
//                                   /@@%%%%%%%@#                               &@######%@/                     %@&@&%%@@
//                                  @@%%%%%%%%@&                                 @%####@@                        *@@@@@(
//                                ,@@%%%%%%%%%@(              %@@@@,             @###@@                          ,@&@&
//                                @@%%%%%%%%%%@*             /@@@@@@             @@##%@,                           %@%@%
//                               &@%%%%%%%%%%%@/              &@@@@*             @@##@@              /(,           ,@%&@*
//                               @&%%%%%%%%%%%@&                                 @%##@@            %@@@@@           @@@
//                              (@%%%%%%%%%%%%&@/                               %@###&@            *@@@@%          *@%#%@
//                        (@@@@@@&%%%%%%%%%%%%%&@                              (@####%@(                           &@###@*
//                     (@@&%%%%%@@@@@@%%%%%%%%%%&@,                           &@%####&@,                         #@%###@#
//                   /@&%%%%%%%%%&%%%%@@@@@@%%%%%%@@,                       %@########%@*                       @@#####&&
//                  ,@&%%%%%%%%%%%%%%%%&%%%&@@%%%%%%@@(                  ,@@###########@@                     *@#####&@
//                  #@%%%%%%%%%%%%%%%%%%%%%%%@@@@@@%%%&@@%,           /@@@################%@@#               &@@####&@@@@@ %&&/
//                  (@%%%%%%%%%%%%%%%%%%%%%%%#####@@%%%%%%&@@@@@@@@@@@#(/****************/(##%@@@%/,  ,,(&@@@%###%@@&%%%%@@&%%&@@@@@@@@, %&(
//                  /@%%%%%%%%%%%%%%%%%%%%########&@%%%%%%%%%%%%@@@%/*************#@@@@@#******(@@@%############@@%%%%%%%%%%%%%%%%%%%%%@##@@
//                  *@&%%%%%%%%%%%%%%%%%##########@@%%%%%%%%%%@@#***************(@@@@@@@@@(********&@@#########@@%%%%%%%%%%%%%%%%%%%%%%#####%@*
//                  ,@&%%%%%%%%%%%%%%%############@@%%%%%%%%%@@*****************@@@@@@@@@@@**********&@%######%@&%%%%%%%%%%%%%%%%%%%%%#######@@
//                   @@%%%%%%%%%%%%%%%###########%@%%%%%%%%%%@@,****************&@@@@@@@@@&***********#@#####%%@@%%%%%%%%%%%%%%%%%%%%%#######%@,
//                   @@%%%%%%%%%%%%%%%###########@&%%%%%%%%%%&@/******************&@@@@@&*************(@%####%%&@%%%%%%%%%%%%%%%%%%%%%%#######@/
//                   %@%%%%%%%%%%%%%%%%#########@&%%%%%%%%%%%%&@%************************************,@@#####%%%@@%%%%%%%%%%%%%%%%%%%%%%######@*
//                   %@%%%%%%%%%%%%%%%########%@&%%%%%%%%%%%%%%%&@@@&%###&@@@@@&%###&@@@@/**********/@@#######%%%@%%%%%%%%%%%%%%%%%%%%%%#####&@
//                  ,@@%%%%%%%%%%%%%########&@&%%%%%%%%%%%%%%%%%%%%%%@@%%%@%,,,,,,,,,,,,,%@@@##&@@@##########%%@@%%%%%%%%%%%%%%%%%%%%%%#####@*
//                ,@@@&%%%%%%%%%%%########@@%%%%%%%%%%%%%%%%%%%%%%%%%@@%%%@&,,,,,,,,,,,,,,%@%%@@#################%@@%%%%%%%%%%%%%%%%%%%####%@,
//                 ,%@%%%%%%%%%%%########@&%%%%%%%%%%%%%%%%%%%%%%%%%%@@%%%@@,,,,,,,,,,,,,,@@%%@@################&@&%%%%%%%%%%%%%%%%%%####@&
//                  @@%%%%%%%%%%%#######&@%%%%%%%%%%%%%%%%%%%%%%%%%%%@@%%%@@,,,,,,,,,,,,,*@&%%@#############@@%##@@%%%%%%%%%%%%%%%%####@%
//                 *@&%%%%%%%%%%%#######@%%%%%%%%%%@@%%%%%%%%%%%%%%%%&@%%%&@*,,,,,,,,,,,,(@%%&@%######&@#####%@&@%#%@@%%%%%%%%%%%%%#####@
//                 &@%%%%%%%%%%%########@%&@@&@@%%@@%%%%%%%%%%%%%%%%%%@@%%%@#,,,,,,,,,,,,@@%%@@#######&@%###&@&%%@%%@@%%%%%%%%%%%%#####&&
//                 @@%%%%%%%%%%%########@@@&%%%@&@@%%%%%%%%%%%%%%%%%%%@@%%%@@,,,,,,,,,,,,@&%%@#######%@%#%@@%%%%@@@@@%%%%%%%%%%%%%#####%@
//                /@%%%%%%%%%%%%########@@%%%%%@@%%%%%%%%%%%%%%%%%####%@&%%&@/,,,,,,,,,,#@%%&@#########@&@@&%%%%%&@%%@&%%%%%%%%%%#######@/
//                &@%%%%%%%%%%%%########@&%%%%%%%%%%%%%%%%%%%%%########@@%%%@@,,,,,,,,,,@&%%@@#########%@&%%%%%%%%###@@%%%%%%%%%%#######@@
//                @&%%%%%%%%%%%%########@&%%%%%%%%%%%%%%%%%%###########%@%%%%@&,,,,,,,,@@%%&@###########@&%%%%%%%####@@%%%%%%%%%%%########@%
//                @%%%%%%%%%%%%#########@&%%%%%%%%%%%%%%%%##############&@%%%%@@,,,,,,@@%%%@############@&%%%%%%%####&@%%%%%%%%%%%########%@,
//                @%%%%%%%%%%%%#########@&%%%%%%%%%%%%%%%################@@%%%%&@@%#@@&%%%@@############@&%%%%%%%%###&@%%%%%%%%%%%%########@@
//                &%%%%%%%%%%%%#########@&%%%%%%%%%%%%%%##################@@%%%%%%%%%%%%%@@#############@@%%%%%%%%%##%@&%%%%%%%%%%%#########@(
//                %%%%%%%%%%%%%#########@&%%%%%%%%%%%%%#####################@@&%%%%%%%%%@###############@%%%%%%%%%%%%@@%%%%%%%%%%%%#########&@,
//                %%%%%%%%%%%%%#########@&%%%%%%%%%%%%########################&@@&%%%&@@%###############@&%%%%%%%%%%%%@@%%%%%%%%%%%%#########@&
//  ------------------------------------------------------------------------------------------------------------------------------------------------
//  ------------------------------------------------------------------------------------------------------------------------------------------------


#import <Foundation/Foundation.h>
#import <stdatomic.h>

#import "UMURLRequest.h"

enum AMConnectionError : NSInteger
{
    kAMConnectionError_InvalidPassword = 1,
    kAMConnectionError_AccessBlocked,
    kAMConnectionError_AccountBalancesFailed,           // userInfo.code contains the code returned from server
    kAMConnectionError_AccountBalanceDetailsFailed,
    kAMConnectionError_HTTPError,                       // userInfo.code contains the HTTP status code (e.g., 500)
    kAMConnectionError_PasswordChangeFailed,            // userInfo.code contains the code returned from server
    kAMConnectionError_AccountMovementsFailed,          // userInfo.code contains the code returned from server
    kAMConnectionError_AccountMovementDetailsFailed,    // userInfo.code contains the code returned from server
    kAMConnectionError_ConversionPaymentFailed,         // userInfo.code contains the code returned from server
    kAMConnectionError_MobileRechargeFailed,            // userInfo.code contains the code returned from server
    kAMConnectionError_OwnAccountsTransferFailed,       // userInfo.code contains the code returned from server
    kAMConnectionError_ISPRechargeFailed,               // userInfo.code contains the code returned from server
    kAMConnectionError_TemplateFailed,                  // userInfo.code contains the code returned from server
    kAMConnectionError_PaymentConfirmFailed,            // userInfo.code contains the code returned from server
    kAMConnectionError_InvoiceListFailed,               // userInfo.code contains the code returned from server
    kAMConnectionError_InvoiceFailed,                   // userInfo.code contains the code returned from server
    kAMConnectionError_JMBA_Exception,                  // userInfo.code contains the exception code returned from server
    kAMConnectionError_SessionExpired,                  // generic "session expired" error mapped from JMB & JMBA
    kAMConnectionError_MABError,                        // generic MAB errors set
    kAMConnectionError_TokenExpired,
    kAMConnectionError_TokenValidationError,
    kAMConnectionError_TokenAuthError,
    kAMConnectionError_SMSRequired,                     // need to approve action with sms
    kAMConnectionError_CertificatesRequired,            // need to send Certificates in the next request
    kAMConnectionError_AccessTokenIsUpdating            // OAuth2 access token process is running
};
typedef enum AMConnectionError AMConnectionError;

enum AMConnectionJMBResultCode : NSInteger
{
    kAMConnectionJMB_OK = 0,
    kAMConnectionJMB_Unknown = 1,
    kAMConnectionJMB_ApplicationException = 2,
    kAMConnectionJMB_ApplicationLogicException = 3,
    kAMConnectionJMB_SessionExpired = 4,
    kAMConnectionJMB_NewVersionExists = 5
};
typedef enum AMConnectionJMBResultCode AMConnectionJMBResultCode;

enum AMConnectionPasswordChangeReason : NSInteger
{
    kAMConnectionPasswordChangeReason_Expiring = 1,
    kAMConnectionPasswordChangeReason_Expired = 2,
    kAMConnectionPasswordChangeReason_Temporary = 3,
    kAMConnectionPasswordChangeReason_Unknown = 4
};
typedef enum AMConnectionPasswordChangeReason AMConnectionPasswordChangeReason;

enum AMConnectionJMBAExceptionCode : NSInteger
{
    kAMConnectionJMBAExceptionCode_OK = 0,
    kAMConnectionJMBAExceptionCode_UNKNOWN_ERROR = 1,
    kAMConnectionJMBAExceptionCode_SESSION_EXPIRED = 2,
    kAMConnectionJMBAExceptionCode_ACCESS_DENIED = 3,
    kAMConnectionJMBAExceptionCode_MALFORMED_JMBP_REQUEST = 4,
    kAMConnectionJMBAExceptionCode_SMS_REQUIRED = 6,
    kAMConnectionJMBAExceptionCode_CERTIFICATES_REQUIRED = 7
};
typedef enum AMConnectionJMBAExceptionCode AMConnectionJMBAExceptionCode;

enum AMFieldType : NSInteger
{
    kAMFieldEdit = 1,
    kAMFieldDate = 2,
    kAMFieldChoice = 3,
    kAMFieldStatic1 = 4,
    kAMFieldImage = 5,
    kAMFieldStatic = 6,
    kAMFieldReserved1 = 7,
    kAMFieldReserved = 8
};
typedef enum AMFieldType AMFieldType;

enum AMCardStatus : NSInteger
{
    kAMCardStatusActive = 0,
    kAMCardStatusTempBlocked = 3,
    kAMCardStatusBlocked = 12,

    kAMVCardStatusActive = 0,
    kAMVCardStatusTempBlocked = 20
};
typedef enum AMCardStatus AMCardStatus;

enum AMCardBlockStatus : NSInteger
{
    AMCardBlockStatusActivate = 0,
    AMCardBlockStatusBlock = 1
};
typedef enum AMCardBlockStatus AMCardBlockStatus;

@class BASE_Connection;

@protocol BASE_ConnectionDelegate

@required

//  Login, you will be called with one of three variants:
- (void)amConnectionLoginCompleted:(BASE_Connection*)connection withResult:(NSDictionary*)result;
- (void)amConnectionPasswordChangeRequested:(BASE_Connection*)connection withReason:(AMConnectionPasswordChangeReason)reason;
- (void)amConnection:(BASE_Connection*)connection loginFailed:(NSError*)error;
- (void)amConnectionLogoutCompleted:(BASE_Connection*)connection;
- (void)amConnectionSessionForWatchCompleted:(BASE_Connection*)connection;
- (void)amConnectionSessionForWatchFailed:(BASE_Connection*)connection;

//  Account change name
- (void)amConnection:(BASE_Connection*)connection processAccountChangeName:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection accountChangeNameFailed:(NSError*)error;

//  Password change
- (void)amConnection:(BASE_Connection*)connection passwordChangeCompleted:(NSString*)newPassword;
- (void)amConnection:(BASE_Connection*)connection passwordChangeFailed:(NSError*)error;

//  Mobile recharge

- (void)amConnection:(BASE_Connection*)connection processMobileRecharge2:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection mobileRecharge2Failed:(NSError*)error;

//  Template payment

- (void)amConnection:(BASE_Connection*)connection processTemplate1:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection template1Failed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processTemplate2:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection template2Failed:(NSError*)error;

//  New Template payment
- (void)amConnection:(BASE_Connection*)connection processNewTemplate1:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection newTemplate1Failed:(NSError*)error;

//  Invoice payment
- (void)amConnection:(BASE_Connection*)connection processInvoiceList:(NSArray*)templates;
- (void)amConnection:(BASE_Connection*)connection invoiceListFailed:(NSError*)error;

//	Generic confirm payment
- (void)amConnection:(BASE_Connection*)connection processConfirmPayment:(NSString*)result;
- (void)amConnection:(BASE_Connection*)connection confirmPaymentFailed:(NSError*)error;

//  Offers
- (void)amConnection:(BASE_Connection*)connection processOfferList:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection offerListFailed:(NSError*)error;

//  Goals
- (void)amConnection:(BASE_Connection*)connection processGoalsList:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection goalsListResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processCreateGoalInit:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection createGoalInitFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processCreateGoal:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection createGoalFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processCreateGoalConfirmation:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection createGoalConfirmationFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection agreeWithNotificationResponse:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection agreeWithNotificationFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processViewGoal:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection viewGoalFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processEditGoal:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection editGoalFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processSaveGoal:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection saveGoalFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processReplenishGoal:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection replenishGoalFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processReplenishGoalRegister:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection replenishGoalRegisterFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processReplenishGoalConfirm:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection replenishGoalConfirmFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processWithdrawGoal:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection withdrawGoalFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processWithdrawGoalRegister:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection withdrawGoalRegisterFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processWithdrawGoalConfirm:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection withdrawGoalConfirmFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processDeleteGoal:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection deleteGoalFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processDeleteGoalConfirm:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection deleteGoalConfirmFailed:(NSError*)error;

//  PFM

- (void)amConnection:(BASE_Connection*)connection processPFMGetCategories:(NSArray*)categories;
- (void)amConnection:(BASE_Connection*)connection pfmGetCategoriesFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processPFMSetCategory:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection pfmSetCategoryFailed:(NSError*)error;

//  Transfers JMBA
- (void)amConnection:(BASE_Connection*)connection processTransferGetFieldsResponse:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection transferGetFieldsResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processTransferRegisterResponse:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection transferRegisterResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processTransferConfirmResponse:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection transferConfirmResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processGetCatalogResponse:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection transferGetCatalogResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processGetBankResponse:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection transferGetBankResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processGenerateOTPResponse:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection transferGenerateOTPResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processSuggestionResponse:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection suggestionResponseFailed:(NSError*)error;

//  Cards JMBA
- (void)amConnection:(BASE_Connection*)connection processPlasticCardsListResponse:(NSArray*)result;
- (void)amConnection:(BASE_Connection*)connection plasticCardsListResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processSetCardStatus:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection setCardStatusFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processSetCardStatusConfirm:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection setCardStatusConfirmFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processCardRemapInit:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection cardRemapInitFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processCardRemap:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection cardRemapFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processCardRemapConfirm:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection cardRemapConfirmFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processCardLimitsResponse:(NSArray*)result;
- (void)amConnection:(BASE_Connection*)connection cardLimitsResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processCardLimitEditFieldsResponse:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection cardLimitEditFieldsResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processCardLimitEditConfirmResponse:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection cardLimitEditConfirmResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processCardLimitAddFieldsResponse:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection cardLimitAddFieldsResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processCardLimitAddConfirmResponse:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection cardLimitAddConfirmResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processCardLimitDeleteResponse:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection cardLimitDeleteResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processVCardCVC2Response:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection vCardCVC2ResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processVCardDelete:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection vCardDeleteFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processVCardDeleteConfirm:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection vCardDeleteConfirmFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processVCardCreateInit:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection vCardCreateInitFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processVCardCreate:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection vCardCreateFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processVCardCreateConfirm:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection vCardCreateConfirmFailed:(NSError*)error;

// P2P Transfer
- (void)amConnection:(BASE_Connection*)connection processCustomerCardsList:(NSArray*)result;
- (void)amConnection:(BASE_Connection*)connection customerCardsListResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processDeleteCustomerCard:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection deleteCustomerCardResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processCalculateFeeTemplateTransfer:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection calculateFeeTemplateTransferResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processSaveTransferTemplate:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection saveTransferTemplateResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processEditTransferTemplate:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection editTransferTemplateResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processDeleteTransferTemplate:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection deleteTransferTemplateResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processTransferTemplatesFields:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection transferTemplatesFieldsResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processTransferTemplateDetails:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection transferTemplateDetailsResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processOperatorByPhoneNumber:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection operatorByPhoneNumberResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection vipManagerGetInfo:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection vipManagerGetInfoFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection doRequestAccountsForMobilePayment:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection doRequestAccountsForMobilePaymentFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processOneButtonPayments:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection oneButtonPaymentsResponseFailed:(NSDictionary*)result;

- (void)amConnection:(BASE_Connection*)connection processGetCommonMovements:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection getCommonMovementsResponseFailed:(id)request withError:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processGetAccountMovementFilters:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection getAccountMovementFiltersResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processGetAccountDetails:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection getAccountDetailsResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processGetAccounts:(NSArray*)result;
- (void)amConnection:(BASE_Connection*)connection getAccountsResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection customRequest:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection customRequestResponseFailed:(NSDictionary*)result;

- (void)amConnection:(BASE_Connection*)connection processGetCurrencyRates:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection getCurrencyRatesResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processGetCurrencyRatesWithParameters:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection getCurrencyRatesWithParametersResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processGetOperationReceiptInPdf:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection getOperationReceiptInPdfResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processGetCryptoCardData:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection getCryptoCardDataResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processCalculateFee:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection calculateFeeResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processDeleteTokens:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection deleteTokensResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processUnsuspendTokens:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection unsuspendTokensResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processSuspendTokens:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection suspendTokensResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processFastCalculateFee:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection fastCalculateFeeResponseFailed:(NSError*)error;

- (void)amConnection:(BASE_Connection*)connection processGetCardColor:(NSDictionary*)result;
- (void)amConnection:(BASE_Connection*)connection getCardColorResponseFailed:(NSError*)error;
@end

#pragma mark -

@interface RequestOperation : NSObject

- (instancetype)initWithOperation:(NSOperation*)operation;

- (void)cancel;

@end

@interface BASE_Request : UMURLRequest
{
@protected
    SEL                         _didFinishSelector;
    SEL                         _didFailSelector;
}
@property (assign) SEL didFinishSelector;
@property (assign) SEL didFailSelector;
@property (nonatomic, strong) NSDictionary* options;

@end

#pragma mark -

@interface BASE_Connection : NSObject <UMURLRequestDelegate>
{
@protected
    NSString*                   baseURL;
    NSString*                   login;
    NSString*                   password;

    id<BASE_ConnectionDelegate> __weak delegate;

    NSOperationQueue*                  queue;
	
    _Atomic int_fast32_t               _counter; // request counter
}

@property (readonly) BOOL isLoggedIn;
@property (nonatomic, strong) NSString* baseURL;
@property (nonatomic, strong) NSString* sessionID;
@property (nonatomic, strong) NSString* login;
@property (nonatomic, strong) NSString* password;
@property (nonatomic, weak) id<BASE_ConnectionDelegate> delegate;

@property (nonatomic, strong) NSMutableArray* accounts;
@property (nonatomic, strong) NSMutableArray* cards;

// pure virtual common set of requests (JMB & MAB-JMB mapped)

// miscellanea

- (void)doLogout; // propagates notification, be careful when invoke as 'super'

// some "virtual" methods for fine tune up the connection
- (NSString*)_baseURL;
- (BOOL)_debugCounter;
- (BASE_Request*)_createRequestURL:(NSURL*)url;
- (void)_enqueueRequest:(BASE_Request*)req;

- (NSString*)_currentLocale;
- (NSString*)_deviceName;
- (NSString*)_operationSystemName;
- (NSString*)_operationSystemVersion;
@end
