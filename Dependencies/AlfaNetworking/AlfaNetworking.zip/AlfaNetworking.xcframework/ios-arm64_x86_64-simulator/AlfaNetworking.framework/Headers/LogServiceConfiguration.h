//
//  Здесь опеределены настройки фреймворка отвечающего за логирование в части касающейся Obj-C кода
//

@import SharedProtocolsAndModels;

#define ABTrace(fmt, ...) [ObjcLoggerAdapter logDebug: [NSString stringWithFormat: fmt, __VA_ARGS__]]
