//
//  ABFields.h
//  AlphaBank
//
//  Created by Andrey Toropchin on 20.07.12.
//  Copyright (c) 2012 Unreal Mojo LLC. All rights reserved.
//

@class ABField;

@interface ABFields : NSObject
{
@private
    NSMutableArray* _sections;
    NSMutableDictionary* _dict;
}
- (void)addField:(ABField*)field forSection:(NSString*)section;
- (NSArray*)sections;
- (NSArray*)fieldsForSection:(NSString*)section;
@end

@interface ABField : NSObject
{
@private
    NSString* _key;
    id _value;
}
@property (nonatomic, copy) NSString* key;
@property (nonatomic, copy) id value;
+ (ABField*)fieldWithKey:(NSString*)key value:(id)value;
@end
