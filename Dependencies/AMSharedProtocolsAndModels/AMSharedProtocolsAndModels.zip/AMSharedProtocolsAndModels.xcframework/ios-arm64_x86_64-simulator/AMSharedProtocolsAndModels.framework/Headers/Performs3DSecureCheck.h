//  Created by Ivan Golikov on 25/10/2019.

#import "Provides3DSecureResultCallback.h"

/// Интерфейс для легаси-компонента выполнения проверки 3D Secure при карточных переводах
@protocol Performs3DSecureCheck  <NSObject>
@property (nonatomic, weak) id<Provides3DSecureResultCallback> callbackDelegate;
@property (nonatomic, strong) NSURL* termURL;

- (instancetype)initWithParent:(UINavigationController*)iparent notificationCenter:(NSNotificationCenter*)notificationCenter;
- (void)openURL:(NSURL*)url withParams:(NSArray*)params;
@end
