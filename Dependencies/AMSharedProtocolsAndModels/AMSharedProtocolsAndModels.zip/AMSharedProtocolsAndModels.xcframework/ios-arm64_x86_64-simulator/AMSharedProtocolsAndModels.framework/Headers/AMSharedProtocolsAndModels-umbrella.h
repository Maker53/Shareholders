#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "ABFields.h"
#import "AMSharedProtocolsAndModels.h"
#import "Performs3DSecureCheck.h"
#import "Provides3DSecureResultCallback.h"

FOUNDATION_EXPORT double AMSharedProtocolsAndModelsVersionNumber;
FOUNDATION_EXPORT const unsigned char AMSharedProtocolsAndModelsVersionString[];

