//  Created by Ivan Golikov on 25/10/2019.

/// Интерфейс сущности, являющейся делегатом формы 3DS
@protocol Provides3DSecureResultCallback <NSObject>
- (void)transfer3DSecureResult:(NSDictionary*)params error:(NSError*)error;
@end
