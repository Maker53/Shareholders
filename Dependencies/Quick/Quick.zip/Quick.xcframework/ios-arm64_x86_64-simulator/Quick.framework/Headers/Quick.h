#import <Foundation/Foundation.h>

//! Project version number for Quick.
FOUNDATION_EXPORT double QuickVersionNumber;

//! Project version string for Quick.
FOUNDATION_EXPORT const unsigned char QuickVersionString[];

#import <Quick/QuickSpec.h>
#import <Quick/QCKDSL.h>
#import <Quick/QuickConfiguration.h>
