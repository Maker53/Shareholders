//
//  EXDictionary.h
//
//  Created by Cyril Murzin on 11/25/10.
//  Copyright 2010 Mojo LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (EXAppending)
- (id)extraAnyObject;
- (NSDictionary*)extraDictionaryByRemovingNullObjects;
- (NSString*)extraStringForKey:(id)key;
- (NSNumber*)extraNumberForKey:(id)key;
- (NSArray*)extraArrayForKey:(id)key;
- (NSDictionary*)extraDictionaryForKey:(id)key;
@end

@interface NSMutableDictionary (EXAppending)
- (void)appendObject:(id)obj forKey:(id)key;
- (void)extraSetObject:(id)anObject forKey:(id)aKey;
@end

