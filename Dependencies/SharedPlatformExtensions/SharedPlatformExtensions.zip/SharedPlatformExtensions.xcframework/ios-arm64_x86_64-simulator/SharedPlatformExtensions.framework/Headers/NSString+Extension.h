/*!
    @header EXString.h
    @project AlphaBank
    @author Anton Turov
    @creation_date 18.03.2010
    @copyright Copyright (C) 2010. All rights reserved.
*/

/*********        includes        *********/

#import <Foundation/NSString.h>

/*********        EXString class        *********/

@interface NSString (EXCharacters)

+ (id)extraNewlineString;
+ (id)extraCarriageReturnString;
+ (id)extraTabString;
+ (id)extraBackspaceString;
+ (id)extraNewLineSymbolDrawingString;

@end

@interface NSString (EXValueSupport)

+ (id)extraStringWithInteger:(NSInteger)integerValue;
+ (id)extraStringWithUInteger:(NSUInteger)unsignedIntegerValue;

- (NSInteger)extraIntegerValue;
- (NSUInteger)extraUIntegerValue;

@end

@interface NSString (EXSearching)

- (BOOL)extraContainsString:(NSString*)string;
- (NSUInteger)extraIndexOfCharacter:(unichar)character;
- (NSUInteger)extraLocationOfString:(NSString*)string;
- (NSUInteger)extraLocationOfString:(NSString*)string options:(NSUInteger)mask;
- (NSUInteger)extraCountOfString:(NSString*)aString;
- (NSUInteger)extraCountOfString:(NSString*)aString options:(NSUInteger)mask;
- (NSUInteger)extraCountOfCharacterFromSet:(NSCharacterSet*)aSet;
- (NSUInteger)extraCountOfCharacterFromSet:(NSCharacterSet*)aSet options:(NSUInteger)mask;
- (NSUInteger)extraCountOfCharacterFromSet:(NSCharacterSet*)aSet range:(NSRange)range;
- (NSUInteger)extraCountOfCharacterFromString:(NSString*)aString;

- (NSString*)extraStringByTrimmingWhitespaceAndNewlineCharacters;
- (NSString*)extraStringByTrimmingLastWhitespaceAndNewlineCharacters;
- (NSString*)extraStringByTrimmingLastWhitespaceCharacters;
- (NSString*)extraStringByRemoveAllTags;

- (NSUInteger)lineBreakWithCharacterRange:(NSRange)characterRange;

@end

@interface NSString (EXUniqueFilename)

// Extensioin can be nil.
+ (NSString*)extraCreateUniqueFilename:(NSString*)fileName extension:(NSString*)extension;

@end

@interface NSString (EXSHA256Hash)

- (NSString*)sha256HashString;

@end

#define CRC64_INIT  0xffffffffffffffffULL

@interface NSString (EXCRC64)

- (unsigned long long)crc64Hash;
- (NSString*)crc64HashString;

@end

@interface NSString (EXMacTypes)

+ (id)extraStringWithFourCharCode:(FourCharCode)osType;

- (FourCharCode)extraFourCharCode;

@end

#pragma mark -

@interface NSMutableString (EXMutableStringExtensions)

- (void)extraClear;
- (void)extraTrimLastWhitespaceAndNewlineCharacters;
- (void)extraNormalizeSpaces;

@end

/*********        replacement of strings        *********/

typedef enum
{
    EXGlobalReplace = 1,
    EXReplaceWordPrefix = 2,
    EXReplaceWordSuffix = 4,
    EXReplacePartOfWord = 6,
    EXReplaceWholeWord = 8,
    EXReplaceRecursive = 16
} EXReplaceOptions;

@interface NSString (EXSeparation)

- (NSArray*)extraComponentsSeparatedByCharacterFromSet:(NSCharacterSet*)set;
    /*    Search options can be:          */
    /*   •     NSCaseInsensitiveSearch    */
    /*   •     NSLiteralSearch            */
    /*   •     NSBackwardsSearch          */
    /*   •     NSAnchoredSearch           */
- (NSArray*)extraComponentsSeparatedByCharacterFromSet:(NSCharacterSet*)set options:(NSUInteger)options;
- (NSArray*)extraComponentsSeparatedByCharacterFromSet:(NSCharacterSet*)set options:(NSUInteger)options range:(NSRange)range;

@end

@interface NSMutableString (EXReplacement)

    /*    Search options can be:                                                      */
    /*   •     NSCaseInsensitiveSearch                                                */
    /*   •     NSLiteralSearch                                                        */
    /*   •     NSBackwardsSearch                                                      */
    /*   •     NSAnchoredSearch                                                       */
    /*    Returs YES if at least one replacement occured                              */
    /* with NSGlobalSearch && EXReplaceRecursive set :                                */
    /* in:     iiiiiiiiiiio                                                           */
    /* replace: io with: oi                                                           */
    /* out:    oiiiiiiiiiii                                                           */
    /* if delimiterCharacters not set [NSCharacterSet whitespaceCharacterSet] is used */
    /* if wordCharacters not set [NSCharacterSet alphanumericCharacterSet] is used    */
- (BOOL)extraReplaceString:(NSString*)substring withString:(NSString*)replacement;
- (BOOL)extraReplaceString:(NSString*)substring withString:(NSString*)replacement searchOptions:(NSUInteger)searchOptions;
- (BOOL)extraReplaceString:(NSString*)substring withString:(NSString*)replacement replaceOptions:(EXReplaceOptions)replaceOptions;
- (BOOL)extraReplaceString:(NSString*)substring withString:(NSString*)replacement searchOptions:(NSUInteger)searchOptions replaceOptions:(EXReplaceOptions)replaceOptions;
//- (BOOL) extraReplaceString:(NSString*)substring withString:(NSString*)replacement searchOptions:(NSUInteger)searchOptions replaceOptions:(EXReplaceOptions)replaceOptions range:(NSRange)range;
//- (BOOL) extraReplaceString:(NSString*)substring withString:(NSString*)replacement searchOptions:(NSUInteger)searchOptions replaceOptions:(EXReplaceOptions)replaceOptions range:(NSRange)range delimiterCharacters:(NSCharacterSet*)delimiters wordCharacters:(NSCharacterSet*)wordCharacters;

@end

@interface NSString (EXCompare)

- (NSComparisonResult)extraNumericCompare:(NSString*)string;

@end

@interface NSString (EXExtensions)

- (NSString*)stringByAddingPercentEscapesForRequest;
- (NSString*)extraStringByAddingPercentEscapesForRequest;
- (NSString*)extraApplyMask:(NSString*)mask;
- (CGSize)extraSizeWithFont:(UIFont*)font;
- (CGSize)extraSizeWithFont:(UIFont*)font constrainedToSize:(CGSize)size;
- (CGSize)extraSizeWithFont:(UIFont*)font constrainedToSize:(CGSize)size lineBreakMode:(NSLineBreakMode)lineBreakMode;

@end

@interface NSString (EXXMLAdditions)

- (NSString *)stringBySanitizingAndEscapingForXML;
- (NSString *)stringBySanitizingToXMLSpec;

@end

#pragma mark -

/*!
    @category NSString (EXROT13Extensions)
 */

@interface NSString (EXROT13Extensions)

/*!
    @method rot13StringFromString:
    @abstract Return a converted string from source string
    @param sourceString string
    @result A converted string
 */
+ (NSString*)rot13StringFromString:(NSString*)sourceString;

@end

/*!
    @category NSString (EXROT13Extensions)
 */

@interface NSString (EXVArgsExtensions)

/*!
    @method stringWithFormat:args:
 */
- (NSString*)stringWithReplacedArgs:(NSDictionary*)firstArg, ... NS_REQUIRES_NIL_TERMINATION;

@end
