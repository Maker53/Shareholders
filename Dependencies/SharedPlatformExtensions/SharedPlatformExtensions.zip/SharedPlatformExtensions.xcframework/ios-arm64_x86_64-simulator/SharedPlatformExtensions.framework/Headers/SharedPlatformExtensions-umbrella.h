#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "NSArray+Extension.h"
#import "NSData+Extension.h"
#import "NSDictionary+Extension.h"
#import "NSMutableDictionary+Extension.h"
#import "NSString+Extension.h"
#import "UILabel+Extension.h"

FOUNDATION_EXPORT double SharedPlatformExtensionsVersionNumber;
FOUNDATION_EXPORT const unsigned char SharedPlatformExtensionsVersionString[];

