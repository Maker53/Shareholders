//
//  NSData+TokenString.h
//  AlphaBank
//
//  Created by Alexey Yakunin on 23/09/15.
//  Copyright (c) 2015 Unreal Mojo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (TokenString)

- (NSString*)abTokenString;

@end
