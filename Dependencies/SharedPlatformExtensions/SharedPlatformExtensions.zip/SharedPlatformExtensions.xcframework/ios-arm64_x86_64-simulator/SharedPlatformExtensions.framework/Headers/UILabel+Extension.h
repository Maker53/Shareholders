//
//  UILabel+FrameSize.h
//  AlphaBank
//
//  Created by Alexander Dubikov on 31/12/15.
//  Copyright © 2015 Alfa-Bank. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (FrameSize)

+ (CGRect)frameForLabel:(UILabel *)label maxWidth:(CGFloat)maxWidth;
+ (CGRect)frameForLabel:(UILabel *)label maxWidth:(CGFloat)maxWidth lineBreakMode:(NSLineBreakMode)breakMode;
- (CGFloat)textWidth;

@end
