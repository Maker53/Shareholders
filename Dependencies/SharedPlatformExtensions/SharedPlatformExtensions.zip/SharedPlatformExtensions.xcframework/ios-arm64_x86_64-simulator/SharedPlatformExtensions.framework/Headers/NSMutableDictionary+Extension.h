//
//  NSMutableDictionary+RequestStatus.h
//  AlphaBank
//
//  Created by Alexander Dubikov on 25/08/16.
//  Copyright © 2016 Alfa-Bank. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_CLOSED_ENUM(NSUInteger, ABRequestStatus) {
    ABRequestStatusUnknown = 0,
    ABRequestStatusSMSRequired = 1,
    ABRequestStatusCertificatesRequired = 2,
    ABRequestStatusOK = 3
};

@interface NSMutableDictionary (RequestStatus)

- (ABRequestStatus)requestStatus;
- (void)setRequestStatus:(ABRequestStatus)status;

@end
