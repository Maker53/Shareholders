/*!
    @header EXArray.h
    @project AlphaBank
    @author Anton Turov
    @creation_date 09.12.2009
    @copyright Copyright (C) 2009. All rights reserved.
    @discussion Extensions that implement most frequently used code fragments.
*/

/*********        includes        *********/

#if TARGET_IPHONE_SIMULATOR
#define isApplePaySupported true
#else
#define isApplePaySupported ([PKAddPaymentPassViewController canAddPaymentPass])
#endif

#import <Foundation/NSArray.h>

/*!
    @category NSArray (EXArray)
*/

@interface NSArray (EXArray)

/*!
    @method extraContainsObjectIdenticalTo:
    @discussion Searches by pointer not by value.
*/
- (BOOL)extraContainsObjectIdenticalTo:(id)object;

/*!
    @method extraFirstObject
    @discussion Returns first object or nil if array is empty.
*/
- (id)extraFirstObject;

/*!
    @method extraObjectAtIndex:
    @discussion Returns nil but does not raise if index is out of range.
*/
- (id)extraObjectAtIndex:(NSUInteger)index;

/*!
    @method extraSortedArray
    @discussion Returns sorted array using selector -compare:.
*/
- (NSArray*)extraSortedArray;

/*!
    @method isExtraReorderedArray:
    @discussion Returns YES if all objects in the receiver are identical to all objects in otherArray, but in different order.
*/
- (BOOL)isExtraReorderedArray:(NSArray*)otherArray;

/*!
    @method isExtraReorderedArray:
    @discussion Returns reordered receiver, so that objects in otherArray go first, in their order in otherArray, then objects in the receiver go, with their order in the receiver.
*/
- (NSArray*)extraReorderedArrayAgainstArray:(NSArray*)otherArray;

/*!
    @method isExtraReorderedArray:
    @discussion Compares by pointer not by value.
*/
- (BOOL)isExtraIdenticalToArray:(NSArray*)otherArray;

/*!
    @method extraArrayByRemovingNullObjects:
    @discussion Returns receiver contains no NSNulls.
 */

- (NSArray*)extraArrayByRemovingNullObjects;

@end

/*!
    @category NSMutableArray (EXMutableArray)
*/
@interface NSMutableArray (EXMutableArray)

/*!
    @method extraInsertObjectsFromArray:atIndex:
    @discussion Inserts objects at specified index. Behaves accordingly -insertObjectAtIndex:.
*/
- (void)extraInsertObjectsFromArray:(NSArray*)array atIndex:(NSUInteger)index;

/*!
    @method extraRemoveObjectAtIndex:
    @discussion Removes object at index. Does not raise if index is out of range.
*/
- (void)extraRemoveObjectAtIndex:(NSUInteger)index;

/*!
    @method extraAddObject:
    @discussion Adds object in case it is not nil.
*/
- (void)extraAddObject:(id)obj;

/*!
    @method extraAddObjectOrNil:
    @discussion Adds object to array. Adds [NSNull null] on attempt to add nil pointer.
*/
- (void)extraAddObjectOrNil:(id)obj;

/*!
    @method extraRemoveString:
    @discussion Removes string from array.
*/
- (void)extraRemoveString:(NSString*)string;

@end

@interface NSArray (ApplePayFeatures)

// TODO: Задача на исправление http://jira.moscow.alfaintra.net/browse/IOSTECH-4489
// разбить на функции
+ (NSArray *) addApplePayFeaturesToArray:(NSArray *)array;

@end
